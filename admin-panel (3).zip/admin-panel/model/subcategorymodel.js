const mongoose = require('mongoose');
const subcategorySchema = new mongoose.Schema({
    name:String,
    cat_id:{type:mongoose.Schema.Types.ObjectId,ref:'categories'}
    
});
const subcategoryModel = new mongoose.model('subcategories', subcategorySchema );

module.exports = subcategoryModel;