const express = require('express')
let subcategoryModel = require('../model/subcategorymodel')
let categoryModel = require('../model/categorymodel')
const app = express()
app.use(express.json());
const cetegorydata = async (req, res) => {
    const catData = await categoryModel.find();
    const alldta = await categoryModel.find();
    console.log(alldta)
    res.render('cetegory', {
        name: req.cookies.name,
        allcat: alldta,
        catData: catData,
        allsubcat: '',
        editsubcat: ''
    })
}
// data subcetogry  insert subcetegory form //
const 


subcategory = async (req, res) => {
    let allsubcat = await subcategoryModel.find();
    const name = req.body.name;
    const id = req.body.cat_id;
    const checkname = await subcategoryModel.findOne({ name: name });


    const rqr = {
        cat_id: id,
        name: name
    }
    const savedata = new subcategoryModel(rqr);
    await savedata.save();

    allsubcat = await subcategoryModel.find();
    res.redirect('/displaysubcat');


}


// data display  subcetegory form  /

const displaysubcat = async (req, res) => {
    const catData = await categoryModel.find();
    console.log(catData);
    const display = await subcategoryModel.find().populate("cat_id");
    console.log(display);
    res.render('subcetegory', {
        name: req.cookies.name,
        allsubcat: display,
        catData: catData,
        editsubcat: ''
    })

}
//  delet data  subcetegory form //
const deletesubcat = async (req, res) => {
    const id = req.params.id;
    const de = await subcategoryModel.findByIdAndRemove({ _id: id });
    console.log("subcatdeleted successfully");
    //  res.json(de); 
    res.redirect('/displaysubcat')

}
//  edit data subcetegory form  //
const editsubcat = async (req, res) => {
    let id = req.params.id;
    console.log(id);
    let catData = await categoryModel.find();
    let subdata = await subcategoryModel.find().populate('cat_id');
    let data = await subcategoryModel.findOne({ _id: id });
    res.render('subcetegory', { name: req.cookies.name, catData: catData, allsubcat: subdata, editsubcat: data });


}
// upate data subcetegory form //
const updatesubcat = async (req, res) => {
    let gallsubcat = await subcategoryModel.find();
    const name = req.body.name;
    const id = req.body.cat_id;
    const subid = req.params.id;
    const subresult = await subcategoryModel.findByIdAndUpdate({ _id: subid }, {

        $set: {
            name: name,
            cat_id: id
        }

    })
    res.redirect('/displaysubcat')
}
const subform = async (req, res) => {
    const catData = await categoryModel.find();
    res.render('subcetegory', { name: req.cookies.name, catData: catData, allsubcat: '', editsubcat: '' });
}
//  flitering subcatdata //
const filtersubcat = async (req, res) =>{
    let cat_id = req.query.selectedValue;
    let  catdata;
    if(cat_id !=''){
        catdata = await subcategoryModel.find({cat_id:cat_id}).populate("cat_id");  
    }else{
         catdata = await subcategoryModel.find().populate('cat_id');
    }
    res.json(catdata);

}
// serching subcatdata //
const searching = async (req, res) =>{
    let searchdata = req.query.selectedValue;
     const cta = await categoryModel.find({
        categoryname:{$regex:new RegExp(searchdata ,"i")}
     });
  let subcategory = await subcategoryModel.find({
      cat_id:{$in:cta.map(cetegory => cetegory._id)}
  }).populate('cat_id');
   
     if(subcategory ==''){
        subcategory = await subcategoryModel.find({name:{$regex:new RegExp(searchdata,"i")}}).populate('cat_id');
     }
     res.json(subcategory)
}

module.exports = { subcategory, displaysubcat, deletesubcat, editsubcat, subform, updatesubcat ,filtersubcat,searching}
