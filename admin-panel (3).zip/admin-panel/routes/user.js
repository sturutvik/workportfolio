const express = require('express');
const router = express.Router();
const body = require('body-parser');
const bodyparser = body.urlencoded({ extended: false });
const mongoose = require('mongoose');
const data = async () => {
    const url = "mongodb://127.0.0.1:27017/student";
    await mongoose.connect(url);
    console.log("Connected to database");
}
data();
// 
const verifytoken = require('../model/jwt');
// 

//  role //
// var localStorage =require('node-localstorage').localStorag,
// localStorage = new localStorage('./scratch');
// 
const { dashboard, getform, getpostData, checkusertdata, otp, logout, register } = require("../conteller/cont"); // admin panel
const { gdata, getdata, categorydelete, categoryedit } = require("../conteller/categorycont"); // cetegory data //
const { subcategory, displaysubcat, deletesubcat, editsubcat, subform, updatesubcat, filtersubcat, searching } = require("../conteller/subcategory"); // POSTMAN (API ) , (ui) (subcatogry data) USE//
const { saveproducts, Products, getsubData } = require('../conteller/product'); // productn //
const bodyParser = require('body-parser');
//  role //
const { role, sdrole, deletedrole, editdrole, updatedrole, checkr } = require('../conteller/role');
const passport = require('passport');

router.get('/forgotpassword', (req, res) => {
    res.render('forgot');
});
router.post('/forgot', bodyparser, otp);
router.get('/category', getdata);  // category .
router.post('/cdata', bodyparser, gdata)
router.get('/catedelete/:uniqe_id', categorydelete) // category delete .
router.get('/cateedit', categoryedit) // category edit .
router.get('/admin', dashboard);
router.get('/admin/form', getform);
router.post('/admin/savedata', bodyparser, getpostData);
router.post('/login', bodyparser, checkusertdata);
router.get('/register', register); // register.
router.get('/logout', logout);  // logout.
//

// ************* subcategory *************//
router.get('/subform', verifytoken, subform);// ui thi ejs thi.
router.post('/subcategory', bodyparser, subcategory); // postman api insert.
router.get('/displaysubcat', displaysubcat);  //and subcategory  form display(ui) thi post.
router.get('/deletesubcat/:id', deletesubcat); // deletesubcategory form display(ui)thi get.
router.get("/editsubcat/:id", editsubcat); // editsubcategory form display(ui)
router.post('/updatesubcat/:id', bodyparser, updatesubcat); // ui thi update thi .
router.get('/filtersubdata', filtersubcat);// filtersubcategory.
router.get('/searching', searching);   // search funtion .
// ********** subcategory end **************//

// ************ product **************** //
router.post('/saveproduct', bodyparser, saveproducts);  // product //
router.get('/productdetail', Products);  // product detail.
router.get('/subcatedata', getsubData);
//   

// ************ role **************** //
router.get('/role', role);
router.post('/srole', bodyparser, sdrole);
router.get('/deleterole/:id', deletedrole);
router.get('/editrole/:id', editdrole);
router.post('/updaterole/:id', bodyparser, updatedrole);
// ************ role **************** //

// google oauth //
router.get('/auth/google',
    passport.authenticate('google', { scope: ['profile', 'email',] }));

router.get('/auth/google/callback',
    passport.authenticate('google', {
        successRedirect: '/admin',
        failureRedirect: '/login'
    }));
 //   


module.exports = router;