const usermodel = require('../model/usermodel');
const nodemailer = require('nodemailer');
const rolemodel = require('../model/rolemodel');
// var GoogleStrategy = require('passport-google-oauth20').Strategy;

//  jwt in use token janrate .
var jwt = require('jsonwebtoken')
const secret_key = "secret12345";
//  const  localStorage = require('localStorage');

// role //
//  var localStorage = require('node-localstorage');
//  localStorage = new localStorage('./scratch');

//  
const transproter = nodemailer.createTransport({  // email send  coding //
    port: 465,
    host: "smtp.gmail.com",
    auth: {
        user: 'rutviksasani123@gmail.com',
        pass: 'twuhwqpyoboeiqvm',
    },
    srcure: true,
});
const dashboard = (req, res) => {
    const username = req.cookies.username;
    res.render('index', { name: username });
}
const getform = (req, res) => {
    res.render('form');
}
const getpostData = async (req, res) => {

// role//
    const checkuser = await usermodel.findOne({ email: req.body.email });
    const rolid = req.body.role_id;
    const checkuserrole = await rolemodel.findOne({ rolid }).populate('role_id');
    if (checkuserrole) {
        if (checkuserrole.role_id.rolename == 'Admin') {
            req.flash('info', 'Admin is already registered!');
            res.render('signup', { message2: req.flash('info'), roleData: roleData });
        } else if (checkuserrole.role_id.rolename == 'Manager') {
            const checkmanager = await model.find({ role_id });
            if (checkmanager.length == 2) {
                req.flash('info', 'Two Managers already registered!');
                res.render('signup', { message2: req.flash('info'), roleData: roleData });
            }
            else {

                const mailinfo = {
                    from: 'rutviksasani123@gmail.com',
                    to: req.body.email,
                    subject: "admin panel",
                    text: 'registration',
                    html: '<p> you are now successfuly registered</p>',
                }

                const result = new usermodel({
                    id: 1,
                    name: req.body.name,
                    email: req.body.email,
                    password: req.body.password,
                    token: ''

                })
                // await transproter.sendMail(mailinfo)
                await result.save()
                // token // 

                var token = jwt.sign({ result: result }, secret_key);
                console.log("generated token");
                console.log(token);
                let _id = result._id;
                console.log(_id);
                const res1 = await usermodel.findByIdAndUpdate({ _id }, { $set: { token: token } })
                console.log(res1);
                res.redirect('/admin');

                // ****** end ******** //
            }
        } else if (checkuser) {
                return res.send("email ready exists");

      }else{

        const mailinfo = {
            from: 'rutviksasani123@gmail.com',
            to: req.body.email,
            subject: "admin panel",
            text: 'registration',
            html: '<p> you are now successfuly registered</p>',
        }

        const result = new usermodel({
            id: 1,
            name: req.body.name,
            email: req.body.email,
            password: req.body.password,
            token: ''

        })
        // await transproter.sendMail(mailinfo)
        await result.save()
        // token // 

        var token = jwt.sign({ result: result }, secret_key);
        console.log("generated token");
        console.log(token);
        let _id = result._id;
        console.log(_id);
        const res1 = await usermodel.findByIdAndUpdate({ _id }, { $set: { token: token } })
        console.log(res1);
        res.redirect('/admin');

      }
            // console.log("data converted" + res1)
            // res.send("data converte
    }
}
    //  logout //
    const logout = (req, res) => {
        res.clearCookie('name')
        res.redirect('/login');
    }
    // 
    const checkusertdata = async (req, res) => {
        const checkuser = await usermodel.findOne({

            email: req.body.email,
            password: req.body.password

        });
        if (checkuser) {

            res.cookie("username", checkuser.name);
            console.log(checkuser.Token);

            res.redirect("/admin");

        } else {
            // localStorage.setItem('userToken', JSON.stringify(checkuser.Token));

            res.redirect("/login");

        }

    }
    function cotp() {
        var min = 10000;
        var max = 99999;
        otp = Math.floor(Math.random() * (max - min)) + min;
        return otp;
    }
    let otp = async (req, res) => {
        email = req.body.email;
        let getuser = await usermodel.findOne({ email: req.body.email });
        if (!getuser) {
            res.render("forgot");
        } else {
            otp = cotp();
            const mailinfo = {
                from: "rutviksasani123@gmail.com",
                to: email,
                subject: "rutviksaani",
                text: "reset password",
                html: `<p> your otp is : ${otp}</p>`
            }
            await transproter.sendMail(mailinfo);
            res.render("forgot");
        }

    }
    //
    const register = async (req, res) => {
        const roledata = await rolemodel.find({});
        const username = req.cookies.username;
        res.render('register', {
            roledata: roledata,
            name: username

        })
    }

    module.exports = {
        dashboard,
        getform,
        getpostData,
        checkusertdata,
        otp,
        logout,
        register


    }         