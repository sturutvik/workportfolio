
document.addEventListener("DOMContentLoaded",()=>{

     const drop = document.getElementById("dispcat_id");
     const rediv=document.getElementById('result');
     drop.addEventListener('change',()=>{
          const selectedValue = drop.value;

          fetch(`/filtersubdata?selectedValue=${selectedValue}`)
          .then((response)=> response.json())
          .then((dta) =>{
           let tr ='';
           dta.forEach((e)=>{
            tr +=`<tr><td>${e._id}</td><td>${e.cat_id.categoryname}</td><td>${e.name}</td><td><a href="/editsubcat/${e._id}">Edit</a><a href="/deletesubcat/${e._id}">Delete</td></tr>`
             
           })
           rediv.innerHTML= tr;
          })
          .catch((error)=>{
               console.error('error:', error);
          });
    
     });
     //  searching fuction //
     const serachbox=document.getElementById('search');
     serachbox.addEventListener('keyup',()=>{
          const selectedValue =serachbox.value;

          fetch(`/searching?selectedValue=${selectedValue}`)
          .then((response)=> response.json())
          .then((dta) =>{
           let tr ='';
           dta.forEach((e)=>{
            tr +=`<tr><td>${e._id}</td><td>${e.cat_id.categoryname}</td><td>${e.name}</td><td><a href="/editsubcat/${e._id}">Edit</a><a href="/deletesubcat/${e._id}">Delete</td></tr>`
             
           })
           rediv.innerHTML= tr;
          })
          .catch((error)=>{
               console.error('error:', error);
          });
    
     });


});

//   product //

const categoryDropdown = document.getElementById("cat_id");

categoryDropdown.addEventListener('change', () => {
    const SValue = categoryDropdown.value;
    const xyz = document.getElementById("sub_id")
    fetch(`/filtersubdata?SValue=${SValue}`)
        .then((response) => response.json())
        .then((data) => {
            let tr = '<option> -- Select Sub-Category -- </option>';
            data.forEach((e) => {
                tr += `<option value = "${e._id}">${e.name}</option>`;
            })
            xyz.innerHTML = tr;
        })
        .catch((error) => {
            console.log('Error Generate:', error);
        });
})