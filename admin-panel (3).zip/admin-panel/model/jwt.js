var jwt = require('jsonwebtoken')
const secret_key = "secret12345";
const  localStorage = require('localStorage');
const verifytoken = (req,res,next) =>{
    let b  = localStorage.getItem('userToken');
    if(b !='undefined'){
      let token =JSON.parse(b);
      jwt.verify(token,secret_key , function(err,decoded) {
        if(err){
            console.log(err);
            res.redirect('/');
        }else{
            next();
        }
      
      })
      
    }else{
        res.redirect('/');
    }
}
module.exports = verifytoken;