
const mongoose = require('mongoose');
const findOrCreate = require('mongoose-findorcreate');


const studentschema = new mongoose.Schema({
    id :Number,
    name:{
         type:String,
         required:true,
         unique:true,
    },
    email:{
        type:String,
        required:true,
        unique:true,
   },
    password:String,
    token:String,
    role_id:{type:mongoose.Schema.Types.ObjectId,ref:'role'},
    googleId: String,
});

studentschema.plugin(findOrCreate)
const studentsmodel = new mongoose.model('database',studentschema)
module.exports=studentsmodel