const express = require('express');
let subcategoryModel = require('../model/subcategorymodel');
let categoryModel = require('../model/categorymodel');
const prodModel = require("../model/productm");
// ********* // *********// *********// ***********//

const fs = require("fs");
const app = express();
app.use(express.json());
const bodyParser = require('body-parser');
app.use(bodyParser.json());

// 
 const Products =  async(req,res)=>{
    getdata = await categoryModel.find();
    res.render('product', {
        name: req.cookies.name,
        catData: getdata,
        
        
        
    })
 }
  // 
  const getsubData = async (req, res) => {
    let catid = req.query.SValue;
    let data = await subcategoryModel.find({ cat_id: catid })
    if (data) {
        res.json(data);
    }
}

 //
 const saveproducts = async(req, res,next)=>{
    try {
        const path = '././images/' + Date.now() + '.png'

        const imgdata = req.body.image;
        if (!imgdata) {
            throw new Error('Invalid image data');
        }
        // to convert base64 format into random filename
        const base64Data = imgdata.replace(/^data:([A-Za-z-+/]+);base64,/, '');
        fs.writeFileSync(path, base64Data, { encoding: 'base64' });
        const result = {
            Cat_id: req.body.Cat_id,
            Sub_id: req.body.sub_id,
            price: req.body.price,
            name: req.body.name,
            images: [base64Data]
        }
        const savedata = new prodModel(result);
        await savedata.save();
        res.redirect('/productdetail');
    } catch (err) {
        next(err);
    }
}

    
 
module.exports= {Products,saveproducts ,getsubData};