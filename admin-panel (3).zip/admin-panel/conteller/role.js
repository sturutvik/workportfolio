const express = require('express');
const rolemodel = require('../model/rolemodel');
const { json } = require('body-parser');
// 
// var localStorage =require('node-localstorage').localStorag,
// localStorage = new localStorage('./scratch');
// //
const app = express();
// 
app.use(express.json());
let editrole = '';
const role = async (req, res) => {
    const getallrole = await rolemodel.find();
    res.render('role', {
        name: req.cookies.name,
        getallrole: getallrole,
        details: '',
        editrole: editrole

    })

}
// 
const sdrole = async (req, res) => {
    const getallrole = await rolemodel.find();
    let l = getallrole.length + 1;
    const rolname = req.body.rolname;
    const checkname = await rolemodel.findOne({ rolname: rolname });
    if (checkname) {
        res.render('role', {
            name: req.cookies.name,
            getallrole:'',
            editrole: ''
        });
    } else {
        const result = {
            rolname: rolname,
            isActive: 1
        }
        const savedata = new rolemodel(result);
        await savedata.save();
      res.redirect('/role');
       

    }

}
// delterole //
const deletedrole = async (req, res) => {
    const id = req.params.id;
    const data = await rolemodel.findByIdAndRemove({ _id: id });
    res.redirect('/role')


}
// editrole //

const editdrole = async (req, res) => {
    const id = req.params.id;
    getallrole = await rolemodel.find();
    editrole = await rolemodel.findOne({ _id: id });
    if (editrole) {
        res.render('role', {
            name: req.cookies.name,
            getallrole:getallrole,
            editrole: editrole
        });
    }

}
//  update role //
const updatedrole = async (req, res,) => {
    const id = req.params.id
    const rolname = req.body.rolname;
    const result = await rolemodel.findByIdAndUpdate({ _id: id},
        {
            $set: {
                rolname: rolname
            }
        })
    

      res.redirect('/role');
}

// 
const checkr = async (req, res) => {
//   let  role = json.parse(localStorage.getItem('role'));
}
module.exports = {
    role,
    sdrole,
    deletedrole,
    editdrole,
   updatedrole,
   checkr
}