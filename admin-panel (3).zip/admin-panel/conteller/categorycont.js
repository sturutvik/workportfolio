let categoryModel = require('../model/categorymodel');
const express = require('express');
const app = express();
//  insrt category //
const getdata = async (req, res) => {

    const categorydata = await categoryModel.find({})
    res.render('cetegory', { name: req.cookies.name, details: categorydata, dta: '' });
}
// *************************//
const gdata = async (req, res) => {
    var todata = await categoryModel.countDocuments();
    // updete category//
    if (req.body.id != "") {
        let udta = await categoryModel.findOne({ _id: req.body.id });
        if (udta) {
            let udata = await categoryModel.updateOne({ _id: req.body.id }, { $set: { categoryname: req.body.categoryname } })
            console.log(udata);
        }
        // res.send("data updated successfully");
    } else {
        const result = new categoryModel({
            id: (todata + 1),
            categoryname: req.body.categoryname,

        });
        const res1 = await result.save()

        
    }
    res.redirect('/category')
}

// category display //
const categorydisplay = async (req, res) => {
    const categorydata = await categoryModel.find({})
    if (!categorydata) {
        console.log(err);
    } else {
        res.render('cetegory', {
            name: req.cookies.name,
            details: categorydata,
            dta: dta,

        });
    }
}
//  delete category //
const categorydelete = async (req, res) => {
    let id = req.params.uniqe_id;
    await categoryModel.deleteOne({ _id: id });
    res.redirect('/category')
}
//    edit category //
const categoryedit = async (req, res) => {
    let id = req.query.id;
    console.log(id);
    let dta = await categoryModel.findOne({ _id: id });
    console.log(dta);
    const categorydata = await categoryModel.find({});
    res.render('cetegory', {
        name: req.cookies.name,
        details: categorydata,
        dta: dta,

    });
}

module.exports = {
    getdata,
    gdata,
    categorydelete,
    categoryedit

} 