const mongoose = require("mongoose");

const pr = async () => {
    const url = "mongodb://127.0.0.1:27017/student";
    await mongoose.connect(url);
};

pr();

const product = new mongoose.Schema({
    name: String,
    Cat_id: { type: mongoose.Schema.Types.ObjectId, ref: 'InfoCat' },
    SubCat_id: { type: mongoose.Schema.Types.ObjectId, ref: 'SubCategory'},
    price:Number,
    images: Array
});

const prodModel = new mongoose.model("Product", product);

module.exports = prodModel;
