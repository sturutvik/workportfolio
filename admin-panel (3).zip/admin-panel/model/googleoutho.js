
const passport = require('passport');
const mongoose = require('mongoose');
const model= require('./usermodel');
var GoogleStrategy = require('passport-google-oauth20').Strategy;

passport.serializeUser((user , done) => { 
    done(null , user); 
  }) 
  passport.deserializeUser(function(user, done) { 
    done(null, user); 
  }); 

  passport.use(GoogleStrategy({
    clientID:"753682475228-uhcih4cs58eltg0aahqf37bt7na2ji9p.apps.googleusercontent.com",
    clientSecret:"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",
    callbackURL:"http://localhost:1111/auth/google/callback"
  },
  function(accessToken, refreshToken, profile, cb) {
    console.log(profile);
    model.findOrCreate({ googleId: profile.id }, function (err, user,random) {
      if(random){
        user.random = true;
        user.profile= profile;
        return cb(err,user);
      }else{
        user.random =false;
        console.log('updated "%s"',user.googleId);
        return cb(err,user);
        
        
      }
    });
  }
  ));